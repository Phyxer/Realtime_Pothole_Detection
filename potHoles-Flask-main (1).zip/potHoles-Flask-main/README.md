# SPOTHOLES-WEBSITE

This project is a web application developed using Flask web framework and Firebase for the backend. The project allows users to perform various tasks, such as signing up, logging in, and adding data to the database.

## Requirements

to run this project type given line in terminal

python "app.py

